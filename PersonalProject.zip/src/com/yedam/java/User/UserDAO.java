package com.yedam.java.User;

public interface UserDAO {

	public void insert(User user);
	
	
	
	
}
