package com.yedam.app.app;

public class Main {

	public static void main(String[] args) {
		new MemoFrame().run();
	}

}

